﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ScrollBar;

namespace DAT602_Assignment1
{
    public partial class GamePlay : Form
    {

        private PictureBox playerBox;
        private int pTileID = 13;
        private int pPlayerID = 1;
        private int _tileID = 1;
        
       

        private int playerRow = 0;
        private int playerCol = 0;

        // getting the number of rows and columns
        private const int Rows = 10;
        private const int Columns = 10;

        private System.Threading.Timer _timer;
        private System.Windows.Forms.Timer timer1;
        private TimeSpan timeLeft;


        private int playerScore = 0; // getting the player score

        List<Player> lcPlayers = new List<Player>(); // refering to the list of players
        List<Tile> lcTiles = new List<Tile>();



        // the constructor for the game play form
        public GamePlay()
        {
            InitializeComponent();
            InitializeGameBoard();
            CreateBoard();


            timer1 = new System.Windows.Forms.Timer();
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;

            timeLeft = TimeSpan.FromMinutes(5);


            this.KeyDown += OnKeyDown;
            this.KeyUp += OnKeyUp;
            this.KeyPreview = true; // Allows the form to capture keystrokes


        }

        private void MoveNPCTimerCallback(object state)
        {
            // Call the MoveNPC method and pass the ButterflyID
            MoveNPC(_butterflyID);
        }


        private readonly DataAccessGame _dataAccessGame;
        private readonly int _butterflyID;


        private string MoveNPC(int ButterflyID)
        {
            try
            {
                _dataAccessGame.MoveNPC(_butterflyID, _tileID); // Call without assigning to result
                Debug.WriteLine($"NPC {ButterflyID} moved to tile {_tileID}");
                return "Success";  // Return a success message after the move
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error moving NPC: {ex.Message}");
                return "Error"; // Return a string indicating an error
            }
        }



        public GamePlay(DataAccessGame dataAccessGame, int ButterflyID)
        {
            _dataAccessGame = dataAccessGame;
            _butterflyID = ButterflyID;

            _timer = new System.Threading.Timer(MoveNPCTimerCallback, null, 0, 2000);
        }



        // on load we need to gain connection to the database 
        private void GamePlay_Load(object sender, EventArgs e)
        {
            DataAccessGame dataAccessGame = new DataAccessGame();
            string result = dataAccessGame.TestGameConnection();
            MessageBox.Show(result);


            LoadGameData();

            timeLabel.Text = timeLeft.ToString("mm\\:ss");
            timer1.Start();

            boardPanel.Controls.Add(playerBox);
            UpdatePlayerPosition(playerRow, playerCol);

            int ButterflyID = 0;
            var gamePlay = new GamePlay(dataAccessGame, ButterflyID);

        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            timeLeft = timeLeft.Subtract(TimeSpan.FromSeconds(1));

            timeLabel.Text = timeLeft.ToString("mm\\:ss");

            if (timeLeft <= TimeSpan.Zero)
            {
                timer1.Stop();
                timeLabel.Text = "00:00";
                MessageBox.Show("Time is up!");
            }
        }




        // loading game data
        private void LoadGameData()
        {
            DataAccessUser dbAccess = new DataAccessUser();
            DataAccessGame dbAccessGame = new DataAccessGame();

            lcPlayers = dbAccess.GetAllPlayers();
            lcTiles = dbAccessGame.GetAllTiles(this);

            // if there are no tiles, then create the tiles
            var flowerTile = new Tile
            {
                TileID = 1,
                row = 0,
                col = 0,
                Type = Tile.TileType.Flower,
                TileImage = Properties.Resources.flower1,
                FlowerTilesSpanned = 2
            };
            lcTiles.Add(flowerTile);

            var adjacentTile = new Tile
            {
                TileID = 2,
                row = 1,
                col = 0,
                Type = Tile.TileType.Flower
            };
            lcTiles.Add(adjacentTile);
        }



        // creating the board
        private void CreateBoard()
        {
            DataAccessGame dataAccessGame = new DataAccessGame(); // opening the DAO 
            string result = dataAccessGame.MakeBoard(10, 10); // making the board
            MessageBox.Show(result);

            LoadGameData(); // loading the data of the game 
            InitializeGameBoard();
        }




        // initializing a game board
        private void InitializeGameBoard()
        {

            int tileWidth = boardPanel.Width / Columns; // getting the tile width by dividing the width of the panel by the amount of columns
            int tileHeight = boardPanel.Height / Rows; // getting the tile height by dividing the height of the panel by the amount or rows


            // Initialize and configure the player PictureBox
            playerBox = new PictureBox
            {
                Width = tileWidth - 2,
                Height = tileHeight - 2,
                BackgroundImage = Properties.Resources.image, // Set color or image for the player
                BorderStyle = BorderStyle.FixedSingle,
            };

            // Set initial position of the player
            UpdatePlayerPosition(playerRow, playerCol);

            // Add playerBox to the board panel
            boardPanel.Controls.Add(playerBox);
            playerBox.Image = Properties.Resources.bee;
            playerBox.SizeMode = PictureBoxSizeMode.StretchImage;

            Random rand = new Random();

            int flowerTiles = 10;
            int rockTiles = 10;
            int butterflyTiles = 1;

            for (int row = 0; row < Rows; row++) // incrementing through the rows
            {
                for (int col = 0; col < Columns; col++) // for every column in the row
                {
                    Tile.TileType type = Tile.TileType.Empty; // default is empty tiles
                    int flower = 0, rock = 0, butterfly = 0, empty = 1; // which means that the tile is at 1 and is always empty

                    // however, if theres more than 0 flower tiles and its from 0-2, then the type is flower
                    if (flowerTiles > 0 && rand.Next(0, 10) < 2) // 0, 10 means that the flower tiles are between 0 and 10
                    {
                        type = Tile.TileType.Flower;
                        flower = rand.Next(1, 4); // the flower is between 1 and 4
                        flowerTiles--; // not incremented since the flower tiles are being used
                    }

                    // otherwise if there are rock tiles and its from 0-10, then the type is rock
                    else if (rockTiles > 0 && rand.Next(0, 10) < 1)
                    {
                        type = Tile.TileType.Rock;
                        rock = 1;
                        rockTiles--;
                    }
                    
                    else if (butterflyTiles > 0 && rand.Next(0,10) < 1)
                    {
                        type = Tile.TileType.Butterfly;
                        butterfly = 1;
                        butterflyTiles--;
                    }

                    Tile currentTile = new Tile(row * Columns + col, type, flower, rock, butterfly, empty)
                    {
                        row = row,
                        col = col
                    };
                    lcTiles.Add(currentTile); // adding the current tile to the list of tiles

                    // picture box = tile
                    PictureBox tileBox = new PictureBox
                    {
                        Width = tileWidth - 2,
                        Height = tileHeight - 2,
                        BorderStyle = BorderStyle.FixedSingle,
                        Location = new Point(col * tileWidth, row * tileHeight),
                        Tag = currentTile,
                    };

                    // if the current tile is not null and the type is flower and the tile image is not null
                    if (currentTile != null && currentTile.Type == Tile.TileType.Flower && currentTile.TileImage != null)
                    {
                        tileBox.BorderStyle = BorderStyle.FixedSingle;
                        tileBox.Image = currentTile.TileImage;
                        tileBox.Size = new Size(61, 56);
                        tileBox.BackgroundImageLayout = ImageLayout.Stretch;
                        tileBox.BackgroundImage = Properties.Resources.image;


                    }
                    else if (currentTile != null && currentTile.Type == Tile.TileType.Rock && currentTile.TileImage != null)
                    {
                        tileBox.BorderStyle = BorderStyle.FixedSingle;
                        tileBox.Image = currentTile.TileImage;
                        tileBox.Size = new Size(61, 56);
                        tileBox.SizeMode = PictureBoxSizeMode.StretchImage;
                        tileBox.BackgroundImageLayout = ImageLayout.Stretch;
                        tileBox.BackgroundImage = Properties.Resources.image;


                    }
                    else if (currentTile != null && currentTile.Type == Tile.TileType.Butterfly && currentTile.TileImage != null)
                    {
                        tileBox.BorderStyle = BorderStyle.FixedSingle;
                        tileBox.Image = currentTile.TileImage;
                        tileBox.Size = new Size(61, 56);
                        tileBox.SizeMode = PictureBoxSizeMode.CenterImage;
                        tileBox.BackgroundImageLayout = ImageLayout.Center;
                        tileBox.BackgroundImage = Properties.Resources.image;


                    }
                
                    else if (currentTile != null && currentTile.Type == Tile.TileType.Empty && currentTile.TileImage != null)
                    {
                        tileBox.BorderStyle = BorderStyle.FixedSingle;
                        tileBox.Image = currentTile.TileImage;
                        tileBox.Size = new Size(61, 56);
                        tileBox.SizeMode = PictureBoxSizeMode.StretchImage;
                        tileBox.BackgroundImageLayout = ImageLayout.Stretch;
                        tileBox.BackgroundImage = Properties.Resources.image;

                    }
                    tileBox.Click += Tile_Click;

                    boardPanel.Controls.Add(tileBox);

                }

            }
        }


        // updating the tile display
        private void UpdateTileDisplay(Tile tile)
        {
            foreach (Control control in boardPanel.Controls)
            {
                // if whats being controlled is a picture and the tag is a tile (as well as having the tile data the same as what is being currently updated)
                if (control is PictureBox box && box.Tag is Tile tileData && tileData == tile)
                {

                    // if it was a flower, then we get the image 
                    if (tile.Type == Tile.TileType.Flower && tile.flower > 0)
                    {
                        box.BorderStyle = BorderStyle.FixedSingle;
                        box.BackgroundImage = tile.TileImage;
                        box.SizeMode = PictureBoxSizeMode.StretchImage;
                        box.BackgroundImageLayout = ImageLayout.Stretch;
                        box.SizeMode = PictureBoxSizeMode.StretchImage; // Ensures image stretches to fit box
                        box.BackgroundImageLayout = ImageLayout.Stretch;
                        box.BackgroundImage = Properties.Resources.image;
                    }
                    else if (tile.Type == Tile.TileType.Rock && tile.rock > 0)
                    {
                        box.BorderStyle = BorderStyle.FixedSingle;
                        box.BackgroundImage = tile.TileImage;
                        box.SizeMode = PictureBoxSizeMode.StretchImage;
                        box.BackgroundImageLayout = ImageLayout.Stretch;
                        box.SizeMode = PictureBoxSizeMode.StretchImage; // Ensures image stretches to fit box
                        box.BackgroundImageLayout = ImageLayout.Stretch;
                        box.BackgroundImage = Properties.Resources.image;
                    }
                    else if (tile.Type == Tile.TileType.Butterfly && tile.butterfly > 0)
                    {
                        box.BorderStyle = BorderStyle.FixedSingle;
                        box.BackgroundImage = tile.TileImage;
                        box.SizeMode = PictureBoxSizeMode.StretchImage;
                        box.BackgroundImageLayout = ImageLayout.Stretch;
                        box.SizeMode = PictureBoxSizeMode.StretchImage; // Ensures image stretches to fit box
                        box.BackgroundImageLayout = ImageLayout.Stretch;
                        box.BackgroundImage = Properties.Resources.image;
                    }
                    else
                    {
                        box.Image = null;
                        GetTileImage(tile);
                    }
                }
            }
        }


        // Method to get the image for the tile based on its type
        private Image GetTileImage(Tile tile)
        {
            // Default to a grass tile image if the tile is null
            if (tile == null)
                return Properties.Resources.image; // Replace with your grass image resource

            // Return specific images based on the tile type
            return tile.Type switch
            {
                Tile.TileType.Flower => tile.TileImage ?? Properties.Resources.image, 
                Tile.TileType.Rock => tile.TileImage ?? Properties.Resources.image, 
                Tile.TileType.Butterfly => tile.TileImage ?? Properties.Resources.image,
                _ => Properties.Resources.image,                                       // Default grass image for other types
            };
        }


        // on click of a tile
        private void Tile_Click(object? sender, EventArgs e)
        {
            if (sender is PictureBox clickedTile && clickedTile.Tag is Tile tileData)
            {

                // popup asking if they want to collect the selected FLOWER
                if (tileData.Type == Tile.TileType.Flower)
                {
                    DialogResult result = MessageBox.Show("Would you like to collect this flower?", "Collect Flower", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        CollectItem(tileData);
                        UpdateScore(tileData);
                    }
                }
            }


        }


        // what shows up if the tile is clicked on (NOT IN USE - WAS FOR TESTING)
        // to be used in onClick clause
        private string GetTileInfo(Tile tile)
        {
            return tile.Type switch
            {
                Tile.TileType.Flower => $"Tile ID: {tile.TileID}, Type: Flower", // if a flower is clicked on
                Tile.TileType.Rock => $"Tile ID: {tile.TileID}, Type: Rock", // if a rock is clicked on
                Tile.TileType.Butterfly => $"Tile ID: {tile.TileID}, Type: Butterfly",
                _ => $"Tile ID: {tile.TileID}, Type: Grass", // if 'empty' or 'grass' is clicked
            };
        }



        // when the user clicks the 'back' button
        private void button1_Click(object sender, EventArgs e)
        {
            GameLobby gameLobby = new GameLobby();
            gameLobby.Show();
            this.Hide();
        }



        // COLLECTION
        private Dictionary<string, Item> playerInventory = new Dictionary<string, Item>();
        private void CollectItem(Tile tile)
        {
            if (tile.Type == Tile.TileType.Flower && tile.flower > 0)
            {
                int playerID = 1;
                int itemID = 1;
                int tileID = tile.TileID;

                DataAccessGame dataAccessGame = new DataAccessGame();
                string result = dataAccessGame.CollectItem(playerID, itemID, tileID);

                MessageBox.Show(result);
                if (result == "Flower collected" || result == "Collected!")
                {
                    if (playerInventory.ContainsKey("Flower"))
                    {
                        playerInventory["Flower"].Quantity++;
                    }
                    else
                    {
                        playerInventory.Add("Flower", new Item("- Flower", 1));
                    }

                    InventoryBox.Items.Clear();
                    foreach (var item in playerInventory.Values)
                    {
                        InventoryBox.Items.Add($"{item.Name} x{item.Quantity}");
                    }

                }

                tile.Type = Tile.TileType.Empty;
                tile.flower = 0;

                UpdateTileDisplay(tile);
                GetTileImage(tile);
            }
        }




        // updating the player score (based on how many flowers are collected) 
        private void UpdateScore(Tile tile)
        {
            if (tile.Type == Tile.TileType.Flower)
                playerScore += 10;
            else if (tile.Type == Tile.TileType.Empty)
                playerScore -= 5;

            // code for updating teh score on status box in game 
        }





        // PLAYER MOVEMENT
        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    Core.IsUp = true;
                    Debug.WriteLine("Up key released");
                    break;
                case Keys.Down:
                    Core.IsDown = true;
                    Debug.WriteLine("Down key released");
                    break;
                case Keys.Left:
                    Core.IsLeft = true;
                    Debug.WriteLine("Left key released");
                    break;
                case Keys.Right:
                    Core.IsRight = true;
                    Debug.WriteLine("Right key released");
                    break;
            }

        }


        private void OnKeyUp(object sender, KeyEventArgs e)
        {
           switch (e.KeyCode)
            {
                case Keys.Up:
                    Core.IsUp = false;
                    Debug.WriteLine("Up key released");
                    break;
                case Keys.Down:
                    Core.IsDown = false;
                    Debug.WriteLine("Down key released");
                    break;
                case Keys.Left:
                    Core.IsLeft = false;
                    Debug.WriteLine("Left key released");
                    break;
                case Keys.Right:
                    Core.IsRight = false;
                    Debug.WriteLine("Right key released");
                    break;
            }

            MovePlayerOnKeyPress();
        }


        private void MovePlayerByCoords(int newRow, int newCol)
        {
            if (newRow >= 0 && newRow < Rows && newCol >= 0 && newCol < Columns)
            {
                Tile targetTile = lcTiles.FirstOrDefault(t => t.row == newRow && t.col == newCol);

                if (targetTile != null)
                {
                    if (targetTile.Type == Tile.TileType.Rock)
                    {
                        Debug.WriteLine("Cannot move to the rocks!");
                        return;
                    }

                    playerRow = newRow;
                    playerCol = newCol;

                    UpdatePlayerPosition(playerRow, playerCol);
                    Debug.WriteLine($"Moved to: Row = {playerRow}, Col = {playerCol}");
                }
                else
                {
                    Debug.WriteLine($"No valid tile found on Row: {newRow}, Col: {newCol}");
                }
            }
            else
            {
                Debug.WriteLine("Invalid move: Row = {newRow}, Col = {newCol} (Out of bounds)");
            }
        }



        private void PlayerPosition()
        {
            foreach (Control control in boardPanel.Controls)
            {
                if (control is PictureBox box && box.Tag is Tile tile)
                {
                    if (tile.row == playerRow && tile.col == playerCol)
                        box.Image = Properties.Resources.bee;
                }
            }
        }

        private void UpdatePlayerPosition(int row, int col)
        {
            Debug.WriteLine($"Updating player: Row = {row}, Col = {col}");

            int tileWidth = boardPanel.Width / Columns;
            int tileHeight = boardPanel.Height / Rows;

            Point newPosition = new Point(col * tileWidth, row * tileHeight);
            playerBox.Location = newPosition;

            Debug.WriteLine($"Player has moved to: {newPosition}");
        }


        private void MovePlayerOnKeyPress()
        {
            int newRow = playerRow;
            int newCol = playerCol;

            if (Core.IsUp) newRow--;
            if (Core.IsDown) newRow++;
            if (Core.IsLeft) newCol--;
            if (Core.IsRight) newCol++;

            Debug.WriteLine($"Attempting to move to: Row = {newRow}, Col = {newCol}");
            MovePlayerByCoords(newRow, newCol);
        }











    }
}
