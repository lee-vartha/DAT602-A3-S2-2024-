﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DAT602_Assignment1
{
    public class DataAccessGame : DataAccessObject
    {

        // testing the connection
        public string TestGameConnection()
        {
            try
            {
                DataAccessGame.mySqlConnection.Open();
                return "Connection successful for the game";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DataAccessGame.mySqlConnection.Close();
            }
        }


        // making the board
        public string MakeBoard(int pMaxRow, int pMaxCol)
        {
            try
            {
                List<MySqlParameter> p = new List<MySqlParameter>(); // referencing the parameters
                p.Add(new MySqlParameter("@pMaxRow", MySqlDbType.Int32) { Value = pMaxRow }); // adding max row
                p.Add(new MySqlParameter("@pMaxCol", MySqlDbType.Int32) { Value = pMaxCol }); // adding max col

                using (MySqlConnection connection = new MySqlConnection(connectionString)) // using the connection string
                {
                    connection.Open();
                    using (MySqlCommand cmd = new MySqlCommand("make_a_board", connection)) // calling the 'make a board' method from sql
                    {
                        cmd.CommandType = CommandType.StoredProcedure; // setting the command type to 'stored procedure'

                        cmd.Parameters.AddRange(p.ToArray()); // adding the parameters to the command
                        cmd.ExecuteNonQuery(); // execute non query to execute the command
                    }
                }

                return "Board created successfully"; // return a message if the board was created successfully
            }
            catch (Exception ex)
            {
                return $"Error creating board: {ex.Message}";
            }
        }


        // getting all tiles
        public List<Tile> GetAllTiles(GamePlay gamePlay)
        {
            List<Tile> lcTiles = new List<Tile>(); // making a new list instance for tiles

            var aDataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "call GetAllTiles()"); // calling the sql method to get all tiles
            var enumTiles = System.Data.DataTableExtensions.AsEnumerable(aDataSet.Tables[0]);

            // If the current tiles list is empty make a new list otherwise just update
            if (Tile.lcTiles.Count == 0)
            {
                lcTiles = new List<Tile>();

                lcTiles = (from aResult in enumTiles
                           select
                              new Tile
                              (
                                  Convert.ToInt32(aResult["TileID"]),
                                  DetermineTileType(aResult),
                                  Convert.ToInt32(aResult["flower"]),
                                  Convert.ToInt32(aResult["rock"])

                              )).ToList();
            }
            else
            {
                foreach (var aResult in enumTiles) // for each result in the enumTiles (enumTiles is the result of the sql method)
                {
                    // only update parts of the tile that change -- we are not making new tiles
                    int id_offset = Convert.ToInt32(aResult["id"]) - 1; // this means that the id is offset by 1
                    Tile.lcTiles[id_offset].flower = Convert.ToInt32(aResult["flower"]);
                    Tile.lcTiles[id_offset].rock = Convert.ToInt32(aResult["rock"]);
                }
            }

            return lcTiles;

        }


        // determining the tile type based on the tiletype attribute
        private Tile.TileType DetermineTileType(dynamic aResult)
        {
            if (Convert.ToInt32(aResult["flower"]) > 0) // if the flower attribute is greater than 0
                return Tile.TileType.Flower; // return the type being 'flower'
            if (Convert.ToInt32(aResult["rock"]) > 0) // if the rock attribute is greater than 0
                return Tile.TileType.Rock; // return the type being 'rock'
            return Tile.TileType.Empty; // otherwise its 'empty' and its grass
        }


        // method to join the game -- not in use right now
        public string JoinGame(int gamenow, string CurrentUsername)
        {
            List<MySqlParameter> p = new List<MySqlParameter>();
            var gParam = new MySqlParameter("@pGameID", MySqlDbType.VarChar, 50) // getting the game ID
            {
                Value = gamenow
            };
            p.Add(gParam);
            var uParam = new MySqlParameter("@pCurrentUsername", MySqlDbType.VarChar, 50) // getting the current username
            {
                Value = CurrentUsername
            };
            p.Add(uParam);

            var dataSet = MySqlHelper.ExecuteDataset(DataAccessGame.mySqlConnection, "CALL JoinGame(@pGameID, @pCurrentUsername)", p.ToArray()); // calling the method to join the game
             
            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }



        // the method to create a new game in the system
        public string CreateNewGame(int MapID, string CurrentUsername)
        {
            List<MySqlParameter> p = new List<MySqlParameter>(); // getting the parameters
            var mParam = new MySqlParameter("@pMapID", MySqlDbType.Int32) // referencing the MapID
            {
                Value = MapID // the value from the parameter is MapID from Game
            };
            p.Add(mParam); // mParam means map parameter

            var uParam = new MySqlParameter("@pCurrentUsername", MySqlDbType.VarChar, 50) // getting the current username
            {
                Value = CurrentUsername
            };
            p.Add(uParam);

            var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL NewGame(@pMapID, @pCurrentUsername);", p.ToArray()); // calling the new game method in sql


            if (dataSet != null && dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count > 0)
            {
                return dataSet.Tables[0].Rows[0]["Message"].ToString();

            }
            else
            {
                return "This doesnt work!";
            }


        }



        // getting a list of the active games (which is found in a list box in the lobby)
        public List<Game> GetActiveGames()
                {
                    List<Game> lcGames = new List<Game>(); // making a new list of games

                    mySqlConnection.Open();

                    var aDataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL GetActiveGames()"); // calling the method in sql to get active games

                    if (aDataSet.Tables.Count > 0 && aDataSet.Tables[0].Rows.Count > 0) // if the data set tables count is greater than 0 and the rows count is greater than 0
                    {
                        lcGames = (from aResult in aDataSet.Tables[0].AsEnumerable() // lcGames means list of games and the result in the dataset tables would be set as enumerable
                                   select new Game // getting a new game with the following attributes
                                   {
                                       GameID = Convert.ToInt32(aResult["GameID"]),
                                       MapID = Convert.ToInt32(aResult["MapID"]),
                                       Status = aResult["Status"].ToString()
                                   }).ToList();
                    }

                    mySqlConnection.Close();
                    return lcGames;
                }




        // method to delete/kill a game
        public string DeleteGame(int pGameID)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var gameParam = new MySqlParameter("@pGameID", MySqlDbType.Int32) // getting the GameID as an integer
            {
                Value = pGameID
            };
            parameters.Add(gameParam);

            var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL DeleteGame(@pGameID)", parameters.ToArray()); // calling the sql method to delete the game

            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }


        public string MovePlayer(int pPlayerID, int pTileID, string Direction)
        {
            try
            {
                List<MySqlParameter> p = new List<MySqlParameter>
                {
                    new MySqlParameter ("@pPlayerID", MySqlDbType.Int32)
                    {
                        Value = pPlayerID
                    },
                    new MySqlParameter ("@pTileID", MySqlDbType.Int32)
                    {
                        Value = pTileID
                    },
                    new MySqlParameter ("@pDirection", MySqlDbType.VarChar, 50)
                    {
                        Value = Direction
                    }
                };


                var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL MovePlayer(@pPlayerID, @pTileID, @Direction)", p.ToArray());

                return dataSet.Tables[0].Rows[0]["Message"].ToString();
            }
            catch (Exception ex)
            {
                return $"Error with character: {ex.Message}";
            }
        }
     



        public string CollectItem(int pPlayerID, int pItemID, int pTileID)
        {
            try
            {
                List<MySqlParameter> p = new List<MySqlParameter>
                {
                    new MySqlParameter("@pPlayerID", MySqlDbType.Int32) { Value = pPlayerID },
                    new MySqlParameter("@pItemID", MySqlDbType.Int32) { Value = pItemID },
                    new MySqlParameter("@pTileID", MySqlDbType.Int32) { Value = pTileID }
                };

                var dataSet = MySqlHelper.ExecuteDataset(mySqlConnection, "CALL CollectItem(@pPlayerID, @pItemID, @pTileID)", p.ToArray());

                return dataSet.Tables[0].Rows[0]["Message"].ToString();
            }
            catch (Exception ex)
            {
                return $"Error collecting: {ex.Message}";
            }
        }

        public int AddButterfly(int tileID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO Item_Tile (TileID) VALUES (@TileID); SELECT LAST_INSERT_ID();", connection);
                    cmd.Parameters.AddWithValue("@TileID", tileID);
                    var butterflyID = Convert.ToInt32(cmd.ExecuteScalar());
                    return butterflyID; // Assigns the newly created Butterfly ID
                }
                catch (MySqlException ex)
                {
                    Console.WriteLine($"Error adding butterfly: {ex.Message}");
                    return 0;
                }
            }
        }



        public string MoveNPC(int butterflyID, int tileID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand("MoveNPC", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ButterflyID", butterflyID);
                    cmd.Parameters.AddWithValue("@NewTileID", tileID);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return reader["Message"].ToString();
                        }
                    }
                    return "NPC movement done";
                }
                catch (MySqlException ex)
                {
                    return $"Error moving NPC: {ex.Message}";
                }
            }
        }

       

    }


}
