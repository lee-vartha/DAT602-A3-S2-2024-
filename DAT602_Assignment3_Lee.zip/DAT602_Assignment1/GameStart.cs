﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAT602_Assignment1
{
    public partial class GameStart : Form
    {
        private GameLobby gameLobby;

        public GameStart()
        {
            InitializeComponent();
        }


        // when the 'start' button is clicked
        private void btn_start_Click(object sender, EventArgs e)
        {
            GameRegister gameRegister = new GameRegister(gameLobby);
            gameRegister.Show();
            this.Hide();
        }


        // when the user clicks the 'exit' button 
        private void btn_exit_Click(object sender, EventArgs e)
        {
            Close(); // close the application
        }
    }
}
