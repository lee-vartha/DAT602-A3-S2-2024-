﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAT602_Assignment1
{
    public class DataAccessObject
    {
        // getting the connection string    
        public static string connectionString
        {
            get { return "Server=localhost; Port=3306; Database=gamedb; Uid=admin; password=pass;"; }
        }

        private static MySqlConnection _mySqlConnection = null;
        protected static MySqlConnection mySqlConnection
        {
            get
            {
                if (_mySqlConnection == null)
                {
                    _mySqlConnection = new MySqlConnection(connectionString);

                    MySqlHelper.ExecuteDataset(mySqlConnection, "SET autocommit = 0;");
                }

                return _mySqlConnection;

            }
        }
    }
}
