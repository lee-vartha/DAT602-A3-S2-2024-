﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAT602_Assignment1
{
    public delegate void Then();
    public class Player
    {
        public static string CurrentUsername { get; set; } // current username
        public static Player CurrentUser { get; set; } // current user
        public int PlayerID { get; set; } // the player id
        public string Username { get; set; } // player username
        public string Password { get; set; } // player password
        public int Attempts { get; set; } // the attempts of logging in the player has made
        public int TileID { get; set; } // the tile id of the player (in gameplay)

         
        public static List<Player> lcPlayers = new List<Player>(); // making a list of players
        public Boolean Update = false; // update boolean being false - meaning the user 'hasnt had their details updated yet'
        public Then? then; // then delegate which is used to update

        

        // updating the user
        public void UpdateData()
        {
            if (this.Update == true)
            {
                this.updateData();
                if (this.Username == Player.CurrentUsername)
                {
                    Player.CurrentUser.Update = false;
                    Player.CurrentUser.Username = this.Username;
                    Player.CurrentUser.Password = this.Password;
                }
                this.Update = false;
            }
        }


        // updating the data
        private void updateData()
        {
            if (Username != null && Password != null)
            {
                DataAccessAdmin dataAccess = new DataAccessAdmin();
                dataAccess.UpdateUser(this);
            }
        }
    }
}
