﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Mysqlx.Notice.Warning.Types;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ScrollBar;

namespace DAT602_Assignment1
{
    public class Tile
    {
        public int TileID { get; set; } // tile id
        public int row { get; set; } // tile row
        public int col { get; set; } // tile column
        public int flower { get; set; } // tile flower item
        public int rock { get; set; } // tile rock item
        public int butterfly { get; set; } // tile butterfly NPC
        public int home { get; set; } // tile home item

        public int empty { get; set; } // tile empty item
        public TileType Type { get; set; } // tile type
        public Image TileImage { get; set; } // tile image
        public int FlowerTilesSpanned { get; set; } // flower tiles spanned
        public int ItemCount { get; set; } // item count


        // an enumeration of all the tile type (items)
        public enum TileType
        {
            Flower,
            Rock,
            Butterfly,
            Home,
            Empty
        }

        // Array to hold the images
        private Image[] rockImages = new Image[]
        {
            Properties.Resources.rock1,
            Properties.Resources.rock2,
            Properties.Resources.rock3,
            Properties.Resources.rock4
        };


      
        private Image GetRandomRockImage()
        {
            Random rand = new Random();
            int index = rand.Next(rockImages.Length); // Pick a random index (0 to 2)
            return rockImages[index];
        }



        // constructor for tile
        public Tile(int tileID, TileType type, int flower = 0, int rock = 0, int bug = 0, int empty = 0)
        {
            TileID = tileID;
            Type = type;
            this.flower = flower;
            if (Type == TileType.Flower)
            {
                TileImage = Properties.Resources.flower1;

            }
            this.rock = rock;
            if (Type == TileType.Rock)
            {
                TileImage = GetRandomRockImage();
            }
            this.butterfly = butterfly;
            if (Type == TileType.Butterfly)
            {
                TileImage = Properties.Resources.butterfly;
            }
            this.empty = empty;
            if (Type == TileType.Empty)
            {
                TileImage = Properties.Resources.image;
            }
        }

        public Tile()
        {
            TileID = 0;
            Type = TileType.Empty;
            flower = 0;
            butterfly = 0;
            rock = 0;
            empty = 1;
        }
         
        // setting the tile type
        public void SetTileType(string itemType, int count)
        {
            ItemCount = count;
            Type = itemType switch
            {
                "Flower" => TileType.Flower,
                "Rock" => TileType.Rock,
                "Butterfly" => TileType.Butterfly,
                _ => TileType.Empty
            };
        }



        

        public static List<Tile> lcTiles = new List<Tile>();


    }
}
