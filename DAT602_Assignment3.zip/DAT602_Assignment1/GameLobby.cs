﻿using Google.Protobuf.WellKnownTypes;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAT602_Assignment1
{
    public partial class GameLobby : Form
    {
        private bool isAdmin;
        private string currentUsername;
        private int MapID = 1; 



        
        public GameLobby(bool isAdmin, string username)
        {
            InitializeComponent();

            this.isAdmin = isAdmin;
            this.currentUsername = username;

            // testing connection
            DataAccessUser dataAccessUser = new DataAccessUser();
            string result = dataAccessUser.TestUserConnection();
            MessageBox.Show(result);


            // if the user is an admin, then the admin window button can be visible for use
            if (isAdmin)
            {
                adminWin_btn.Visible = true;
            }
            else // otherwise it will stay hidden
            {
                adminWin_btn.Visible = false;
            }

        }

        public GameLobby() : this(true, "Admin") 
        {
            
        }

        // on load
        private void GameLobby_Load(object sender, EventArgs e)
        {
            LoadListOfOnlinePlayers();
            LoadActiveGames();
            DisplayCurrentUser();

            // this was used for generating dummy data for 'active games' (testing)
           // LiveGamesBox.Items.Clear();
            //List<Game> activeGames = GenerateActiveGames();
            //foreach (var game in activeGames)
            //{
            //    LiveGamesBox.Items.Add(game);
            //}
        }


        // used to display the current user (so i can see who is logged in)
        private void DisplayCurrentUser()
        {
            try
            {
                listBox2.Items.Clear();

                listBox2.Items.Add(currentUsername);
            }
            catch (Exception Ex)
            {
                MessageBox.Show($"Error displaying current user: {Ex.Message}");
            }
        }


        // loading the list of online players
        public class PlayerEntryControl : UserControl
        {
            private Label playerNameLabel;

            public PlayerEntryControl(string playerName)
            {
                // Initialize and set up labels and any other controls

                playerNameLabel = new Label
                {
                    Text = playerName,
                    Size = new Size(800, 30), // Set size slightly smaller to fit within the control
                    BorderStyle = BorderStyle.FixedSingle,
                    FlatStyle = FlatStyle.Flat,
                    ForeColor = Color.Sienna,
                    BackColor = Color.Wheat,

                };


                // Layout setup
                this.Controls.Add(playerNameLabel);

            }
        }


        // loading active games
        public void LoadActiveGames()
        {
            try
            {
                DataAccessGame dataAccess = new DataAccessGame();
                List<Game> activeGames = dataAccess.GetActiveGames();

                LiveGamesBox.Items.Clear(); // clearing the gamebox in case of null/expired games

                if (activeGames != null & activeGames.Count > 0)
                {
                    foreach (var game in activeGames)
                    {
                        string gameDetails = $"{game.GameID} - {game.Players} players - {game.StartTime} - {game.Status}";
                        LiveGamesBox.Items.Add(gameDetails);
                    }

                }
                else
                {
                    LiveGamesBox.Items.Add("No games");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading games");
            }
        }


        // generating active games - not in use (this was to test dummy data)
        private List<Game> GenerateActiveGames()
        {

            return new List<Game>
            {
                new Game
                {
                    GameID = 1,
                    Players = 2,
                    StartTime = DateTime.Now,
                    Status = "In Progress"
                },
                new Game
                {
                    GameID = 2,
                    Players = 2,
                    StartTime = DateTime.Now,
                    Status = "In Progress"
                }
                };
        }


        // loading the list of online players (in the list box)
        public void LoadListOfOnlinePlayers()
        {
            try
            {
                DataAccessUser dataAccessUser = new DataAccessUser();
                List<Player> onlinePlayers = dataAccessUser.GetOnlinePlayers(); // using the method from the DAO 

                PlayerListBox.Items.Clear();

                foreach (var player in onlinePlayers)
                {
                    string PlayersDetails = $"{player.Username}";
                    PlayerListBox.Items.Add(PlayersDetails);
                }
            }
            catch
            {
                MessageBox.Show("Error loading players");
            }
        }


        // if the 'admin button' is clicked
        private void adminWin_btn_Click(object sender, EventArgs e)
        {
            GameAdmin gameAdmin = new GameAdmin(this);
            gameAdmin.Show();
            this.Hide();

        }

        // when the 'logout' button is clicked
        private void logout_btn_Click(object sender, EventArgs e)
        {
            string currentUsername = DataAccessUser.CurrentUsername;
            DataAccessUser dataAccessUser = new DataAccessUser();
            dataAccessUser.Logout(currentUsername); // logging out the current user

            LoadListOfOnlinePlayers(); // reloading the list of online players (so that the current user who logged out isnt on the list anymore)

            GameStart gameStart = new GameStart();
            gameStart.Show();
            this.Hide();
        }

        // when the 'delete' button is clicked
        private void deleteAcc_btn_Click(object sender, EventArgs e)
        {
            // Confirm the action with the user
            DialogResult result = MessageBox.Show($"Are you sure you want to delete your account?", "Delete Account", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                DataAccessUser dataAccess = new DataAccessUser(); 
                string response = dataAccess.DeleteSelf(currentUsername); // using the current username

                MessageBox.Show(response);

                if (response.Contains("Deleted User"))
                {
                    GameStart gameStart = new GameStart();
                    gameStart.Show();
                    this.Close(); 
                }
                else
                {
                    LoadListOfOnlinePlayers();
                }
            }

        }

   
        // if the 'new game' button is clicked
        private void newGame_btn_Click_1(object sender, EventArgs e)
        {
            DataAccessGame dataAccess = new DataAccessGame();
            string response = dataAccess.CreateNewGame(MapID, currentUsername);
            MessageBox.Show(response);

            if (response == "Game is created")
            {
                GamePlay gamePlay = new GamePlay();
                gamePlay.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Error making game");
            }

        }
    }
}