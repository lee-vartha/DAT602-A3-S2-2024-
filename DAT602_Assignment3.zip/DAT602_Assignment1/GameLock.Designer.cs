﻿namespace DAT602_Assignment1
{
    partial class GameLock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btn_contactadmin = new Button();
            btn_exit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("SimSun", 15F);
            label1.Location = new Point(74, 42);
            label1.Name = "label1";
            label1.Size = new Size(220, 25);
            label1.TabIndex = 0;
            label1.Text = "Bees and Blossom";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("SimSun", 7F);
            label2.Location = new Point(84, 77);
            label2.Name = "label2";
            label2.Size = new Size(197, 12);
            label2.TabIndex = 1;
            label2.Text = "Sorry, you have been locked out!";
            // 
            // label3
            // 
            label3.BackColor = Color.Transparent;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("SimSun", 10F);
            label3.ImageAlign = ContentAlignment.BottomCenter;
            label3.Location = new Point(42, 105);
            label3.Name = "label3";
            label3.RightToLeft = RightToLeft.No;
            label3.Size = new Size(285, 168);
            label3.TabIndex = 2;
            label3.Text = "You have been temporarily locked out. \r\nCome back after 3 days to retry logging into the game.\r\n\r\nGood luck!\r\n";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btn_contactadmin
            // 
            btn_contactadmin.BackColor = Color.Wheat;
            btn_contactadmin.FlatAppearance.BorderColor = Color.SandyBrown;
            btn_contactadmin.FlatStyle = FlatStyle.Flat;
            btn_contactadmin.Font = new Font("SimSun", 10F);
            btn_contactadmin.ForeColor = Color.Sienna;
            btn_contactadmin.Location = new Point(46, 301);
            btn_contactadmin.Name = "btn_contactadmin";
            btn_contactadmin.Size = new Size(272, 31);
            btn_contactadmin.TabIndex = 5;
            btn_contactadmin.Text = "Contact Administrator";
            btn_contactadmin.UseVisualStyleBackColor = false;
            // 
            // btn_exit
            // 
            btn_exit.BackColor = Color.Wheat;
            btn_exit.FlatAppearance.BorderColor = Color.SandyBrown;
            btn_exit.FlatStyle = FlatStyle.Flat;
            btn_exit.Font = new Font("SimSun", 10F);
            btn_exit.ForeColor = Color.Sienna;
            btn_exit.Location = new Point(46, 342);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(272, 31);
            btn_exit.TabIndex = 6;
            btn_exit.Text = "Exit the Game";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += btn_exit_Click;
            // 
            // GameLock
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.full_background;
            ClientSize = new Size(370, 421);
            Controls.Add(btn_exit);
            Controls.Add(btn_contactadmin);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "GameLock";
            Text = "GameLock";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button btn_contactadmin;
        private Button btn_exit;
    }
}