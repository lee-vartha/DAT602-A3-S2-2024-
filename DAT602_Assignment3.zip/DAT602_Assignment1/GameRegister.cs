﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAT602_Assignment1
{

    public partial class GameRegister : Form
    {
        private GameLobby gameLobby;

        private MySql.Data.MySqlClient.MySqlConnection MySqlConnection; // creating a new connection to the database


        public GameRegister(GameLobby lobby)
        {
            InitializeComponent();
            this.gameLobby = lobby; // setting the game lobby
        }

        // on load, test the connection to the database
        private void GameRegister_Load(object sender, EventArgs e)
        {
            DataAccessUser dataAccessUser = new DataAccessUser();
            string result = dataAccessUser.TestUserConnection();
            MessageBox.Show(result);
        }


        // if the 'switch to login' button is clicked
        private void btn_switch_Click_1(object sender, EventArgs e)
        {
            GameLogin gameLogin = new GameLogin();
            gameLogin.Show();
            this.Hide();
        }


        // clicking the 'register confirm' button
        private void button1_Click(object sender, EventArgs e)
        {
            DataAccessUser gameDB = new DataAccessUser(); // accessing the database
            string result = gameDB.AddUserName(txt_username.Text, txt_password.Text); // calling the add username method
            
            MessageBox.Show(result);

            if (result.Contains("successfully registered")) // if it worked, then open the game lobby - 'false' is setting the 'isAdmin' bool
            {
                GameLobby gameLobby = new GameLobby(false, txt_username.Text);
                gameLobby.Show();
                this.Hide();

            }
        }


        // clicking the 'back to start' button
        private void button2_Click(object sender, EventArgs e)
        {
            GameStart gameStart = new GameStart();
            gameStart.Show();
            this.Hide();
        }
    }
}
