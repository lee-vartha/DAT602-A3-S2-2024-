﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAT602_Assignment1
{
    public partial class AdminEdit : Form
    {

        private Player player; // player object

        private string currentUsername; // getting the current username

        // the constructor for the admin edit form
        public AdminEdit(Player selectedPlayer)
        {
            InitializeComponent();
            player = selectedPlayer; // setting the player object to the selected player
            ShowUser(); // showing the users current details
            DisplayCurrentUser(); // displaying the current user
        }


        // displaying the user
        private void ShowUser()
        {
            txt_username.Text = player.Username;
            txt_password.Text = player.Password;
        }


        // updating the user
        private void UpdateUser()
        {
            player.Username = txt_username.Text;
            player.Password = txt_password.Text;
        }


        // displaying the current user
        private void DisplayCurrentUser()
        {
            try
            {
                listBox1.Items.Clear(); // clearing the list box so any previous username isnt there anymore

                listBox1.Items.Add(currentUsername); // adding the current username
            }
            catch (Exception Ex)
            {
                MessageBox.Show($"Error displaying current user: {Ex.Message}"); // the condition if that wont work
            }
        }


        // button when the admin confirms
        private void btn_confirm_Click(object sender, EventArgs e)
        {
            UpdateUser();
        }


        // button to go back
        private void back_btn_Click(object sender, EventArgs e)
        {
            GameLobby gameLobby = new GameLobby();
            gameLobby.Show();
            this.Hide();
        }
    }

}
