﻿namespace DAT602_Assignment1
{
    partial class AdminEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            login_lbl = new Label();
            label1 = new Label();
            username_lbl = new Label();
            txt_password = new TextBox();
            password_lbl = new Label();
            txt_username = new TextBox();
            textBox1 = new TextBox();
            label2 = new Label();
            btn_confirm = new Button();
            listBox1 = new ListBox();
            back_btn = new Button();
            SuspendLayout();
            // 
            // login_lbl
            // 
            login_lbl.AutoSize = true;
            login_lbl.BackColor = Color.Transparent;
            login_lbl.Font = new Font("SimSun", 18F);
            login_lbl.ForeColor = Color.Sienna;
            login_lbl.Location = new Point(140, 20);
            login_lbl.Name = "login_lbl";
            login_lbl.Size = new Size(88, 30);
            login_lbl.TabIndex = 2;
            login_lbl.Text = "Admin";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("SimSun", 13F);
            label1.ForeColor = Color.Sienna;
            label1.Location = new Point(35, 72);
            label1.Name = "label1";
            label1.Size = new Size(120, 22);
            label1.TabIndex = 3;
            label1.Text = "Edit User:";
            // 
            // username_lbl
            // 
            username_lbl.AutoSize = true;
            username_lbl.BackColor = Color.Transparent;
            username_lbl.Font = new Font("SimSun", 10F);
            username_lbl.ForeColor = Color.Sienna;
            username_lbl.Location = new Point(36, 106);
            username_lbl.Name = "username_lbl";
            username_lbl.Size = new Size(80, 17);
            username_lbl.TabIndex = 11;
            username_lbl.Text = "Username";
            // 
            // txt_password
            // 
            txt_password.Font = new Font("SimSun", 11F);
            txt_password.ForeColor = Color.Sienna;
            txt_password.Location = new Point(36, 246);
            txt_password.Name = "txt_password";
            txt_password.Size = new Size(285, 28);
            txt_password.TabIndex = 9;
            // 
            // password_lbl
            // 
            password_lbl.AutoSize = true;
            password_lbl.BackColor = Color.Transparent;
            password_lbl.Font = new Font("SimSun", 10F);
            password_lbl.ForeColor = Color.Sienna;
            password_lbl.Location = new Point(35, 226);
            password_lbl.Name = "password_lbl";
            password_lbl.Size = new Size(80, 17);
            password_lbl.TabIndex = 10;
            password_lbl.Text = "Password";
            // 
            // txt_username
            // 
            txt_username.Font = new Font("SimSun", 11F);
            txt_username.ForeColor = Color.Sienna;
            txt_username.Location = new Point(36, 126);
            txt_username.Name = "txt_username";
            txt_username.Size = new Size(285, 28);
            txt_username.TabIndex = 8;
            txt_username.Text = "Enter New Username...";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("SimSun", 11F);
            textBox1.ForeColor = Color.Sienna;
            textBox1.Location = new Point(36, 187);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(285, 28);
            textBox1.TabIndex = 12;
            textBox1.Text = "Enter New Email...";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("SimSun", 10F);
            label2.ForeColor = Color.Sienna;
            label2.Location = new Point(35, 167);
            label2.Name = "label2";
            label2.Size = new Size(53, 17);
            label2.TabIndex = 13;
            label2.Text = "Email";
            // 
            // btn_confirm
            // 
            btn_confirm.BackColor = Color.Wheat;
            btn_confirm.FlatAppearance.BorderColor = Color.SandyBrown;
            btn_confirm.FlatStyle = FlatStyle.Flat;
            btn_confirm.Font = new Font("SimSun", 12F);
            btn_confirm.ForeColor = Color.Sienna;
            btn_confirm.Location = new Point(85, 298);
            btn_confirm.Name = "btn_confirm";
            btn_confirm.Size = new Size(189, 31);
            btn_confirm.TabIndex = 14;
            btn_confirm.Text = "Confirm";
            btn_confirm.UseVisualStyleBackColor = false;
            btn_confirm.Click += btn_confirm_Click;
            // 
            // listBox1
            // 
            listBox1.BackColor = SystemColors.Info;
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(158, 73);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(163, 24);
            listBox1.TabIndex = 15;
            // 
            // back_btn
            // 
            back_btn.BackColor = Color.Wheat;
            back_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            back_btn.FlatStyle = FlatStyle.Flat;
            back_btn.Font = new Font("SimSun", 8F);
            back_btn.ForeColor = Color.Sienna;
            back_btn.Location = new Point(19, 12);
            back_btn.Name = "back_btn";
            back_btn.Size = new Size(69, 29);
            back_btn.TabIndex = 38;
            back_btn.Text = "Back";
            back_btn.UseVisualStyleBackColor = false;
            back_btn.Click += back_btn_Click;
            // 
            // AdminEdit
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.full_background;
            ClientSize = new Size(363, 358);
            Controls.Add(back_btn);
            Controls.Add(listBox1);
            Controls.Add(btn_confirm);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(username_lbl);
            Controls.Add(txt_password);
            Controls.Add(password_lbl);
            Controls.Add(txt_username);
            Controls.Add(label1);
            Controls.Add(login_lbl);
            Name = "AdminEdit";
            Text = "AdminEdit";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label login_lbl;
        private Label label1;
        private Label username_lbl;
        private TextBox txt_password;
        private Label password_lbl;
        private TextBox txt_username;
        private TextBox textBox1;
        private Label label2;
        private Button btn_confirm;
        private ListBox listBox1;
        private Button back_btn;
    }
}